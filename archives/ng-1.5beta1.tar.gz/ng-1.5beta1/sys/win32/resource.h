//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by mg.rc
//
#define IDI_APPICON                     101
#define IDD_STARTUPFILE                 102
#define IDD_KEY                         103
#define IDD_BEEP                        104
#define IDB_REBAR                       104
#define IDD_FONT                        105
#define IDR_MAINMENU                    105
#define IDR_PPCMENU                     106
#define IDB_BUTTONS                     107
#define IDD_VIEW                        108
#define IDC_STARTUPFILE                 1000
#define IDC_FILEOPENDLG                 1001
#define IDC_CONTROLMAP                  1002
#define IDC_BEEP                        1003
#define IDC_KEYBOARDLOCALE              1003
#define IDC_MESSAGEBEEP                 1004
#define IDC_PLAYSOUND                   1005
#define IDC_OPTION                      1006
#define IDC_SOUNDFILE                   1007
#define IDC_SOUNDBUTTON                 1008
#define IDC_MESSAGECOMBO                1009
#define IDC_PLAY                        1010
#define IDC_FONTNAME                    1011
#define IDC_POINT                       1012
#define IDC_LINESPACE                   1013
#define IDC_SHOWMENUBAR                 1014
#define IDC_SPIN                        1015
#define IDC_NOSPECIFY                   1016
#define IDC_SPECIFY                     1017
#define IDC_CUT                         1018
#define IDC_COPY                        1019
#define IDC_PASTE                       1020
#define IDC_MARK                        1021
#define IDC_NEXT                        1022
#define IDC_PRIOR                       1023
#define IDC_CLOSE                       1024
#define IDS_FILE                        1025
#define IDS_CONFIGNAME                  1026
#define IDS_OK                          1027
#define IDS_ICONASTERISK                1028
#define IDS_ICONEXCLAMATION             1029
#define IDS_ICONHAND                    1030
#define IDS_ICONQUESTION                1031
#define IDS_CUT                         1032
#define IDS_COPY                        1033
#define IDS_PASTE                       1034
#define IDS_MARK                        1035
#define IDS_NEXT                        1036
#define IDS_PRIOR                       1037
#define IDBN_MARK                       40001
#define IDBN_NEXT                       40002
#define IDBN_PRIOR                      40003
#define IDM_MENUITEM1                   40004
#define IDM_MENUITEM2                   40007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        109
#define _APS_NEXT_COMMAND_VALUE         40008
#define _APS_NEXT_CONTROL_VALUE         1038
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
