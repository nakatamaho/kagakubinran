.. _nao_comp_spatial_distributions:

nao.comp_spatial_distributions --- NAO: Spatial Distribution Density change
*****************************************************************************

.. automodule:: pyscf.nao.m_comp_spatial_distributions
   :members:
