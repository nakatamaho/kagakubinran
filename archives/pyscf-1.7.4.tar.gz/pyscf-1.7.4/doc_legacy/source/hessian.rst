hessian --- Analytical nuclear Hessian
**************************************

.. automodule:: pyscf.hessian
 
