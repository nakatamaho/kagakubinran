ci --- Configuration interaction
***************************************

.. module:: ci
   :synopsis: Computing CI energy and properties
.. sectionauthor:: Qiming Sun <osirpt.sun@gmail.com>.

The :mod:`cc` module implements the truncated CI model to compute energy.

