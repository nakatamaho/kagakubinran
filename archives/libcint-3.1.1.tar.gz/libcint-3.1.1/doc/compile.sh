pandoc --toc -s program_ref.txt -o program_ref.tex
pdflatex program_ref.tex
pdflatex program_ref.tex
