#include "config.h"

void CINTrys_roots(FINT nroots, double x, double *u, double *w);
void CINTstg_roots(FINT nroots, double ta, double ua, double* rr, double* ww);

