Extending via Numba
-------------------

.. literalinclude:: ../../../../../numpy/random/_examples/numba/extending.py
    :language: python
