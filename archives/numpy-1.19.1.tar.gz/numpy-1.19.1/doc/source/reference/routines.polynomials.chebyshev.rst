.. versionadded:: 1.4.0

.. automodule:: numpy.polynomial.chebyshev
   :no-members:
   :no-inherited-members:
   :no-special-members:
