This example demonstrates how Cython-generated code
can be called directly from a main program written in C.

The Windows makefiles were contributed by
Duncan Booth: Duncan.Booth@SuttonCourtenay.org.uk.
