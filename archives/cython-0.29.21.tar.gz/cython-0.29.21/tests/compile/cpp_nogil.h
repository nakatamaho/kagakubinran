struct NoGilTest1 {
  NoGilTest1() { }
  void doSomething() { }
};

struct NoGilTest2 {
  NoGilTest2() { }
  void doSomething() { }
};
