Special Methods Table
---------------------

You can find an updated version of the special methods table
in :ref:`special_methods_table`.

General
^^^^^^^

Rich comparison operators
^^^^^^^^^^^^^^^^^^^^^^^^^

Arithmetic operators
^^^^^^^^^^^^^^^^^^^^

Numeric conversions
^^^^^^^^^^^^^^^^^^^

In-place arithmetic operators
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Sequences and mappings
^^^^^^^^^^^^^^^^^^^^^^

Iterators
^^^^^^^^^

Buffer interface
^^^^^^^^^^^^^^^^

Descriptor objects
^^^^^^^^^^^^^^^^^^
