# Python API for the Extended Tight Binding Program

The Python API for `xtb` has been migrated to its own repository at https://github.com/grimme-lab/xtb-python.
The documentation can be found at https://xtb-python.readthedocs.io.

There is nothing to see here anymore.
